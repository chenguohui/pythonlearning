from distutils.core import setup
setup(name='hello',
      version='1.0',
      description="hello  wordl",
      author="abc",
      py_modules=['hello'],
      )

